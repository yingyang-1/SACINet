_base_ = [
    '../_base_/models/hv_pointpillars_fpn_range100_lyft.py',
    '../_base_/datasets/range100_lyft-3d.py',
    '../_base_/schedules/schedule_2x.py', '../_base_/default_runtime.py'
]
